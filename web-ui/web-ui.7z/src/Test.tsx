import React from 'react';

const Test: React.FC = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1>SQL Server 数据库比较工具</h1>
      <p>测试页面正常工作</p>
      <button onClick={() => alert('按钮点击正常')}>测试按钮</button>
    </div>
  );
};

export default Test;