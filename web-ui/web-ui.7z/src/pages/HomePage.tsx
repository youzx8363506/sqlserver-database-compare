import React, { useState } from 'react';
import {
  Layout,
  Row,
  Col,
  Steps,
  Button,
  Space,
  Typography,
  Alert,
  message,
  Card,
} from 'antd';
import {
  DatabaseOutlined,
  FileTextOutlined,
} from '@ant-design/icons';
import DatabaseConfigForm from '../components/DatabaseConfigForm';
import ComparisonProgress from '../components/ComparisonProgress';
import ComparisonResults from '../components/ComparisonResults';
import { DatabaseConfig, ComparisonResult } from '../types';
import { compareApi } from '../services/api';

const { Header, Content } = Layout;
const { Title, Paragraph } = Typography;

const HomePage: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [sourceConfig, setSourceConfig] = useState<DatabaseConfig | null>(null);
  const [targetConfig, setTargetConfig] = useState<DatabaseConfig | null>(null);
  const [comparisonTaskId, setComparisonTaskId] = useState<string | null>(null);
  const [comparisonResult, setComparisonResult] = useState<ComparisonResult | null>(null);
  const [loading, setLoading] = useState(false);

  // 步骤配置
  const steps = [
    {
      title: '配置数据库',
      description: '设置源数据库和目标数据库连接',
      icon: <DatabaseOutlined />,
    },
    {
      title: '执行比较',
      description: '分析数据库结构差异',
      icon: <DatabaseOutlined />,
    },
    {
      title: '查看结果',
      description: '查看比较结果和生成报告',
      icon: <FileTextOutlined />,
    },
  ];

  // 开始比较
  const startComparison = async () => {
    if (!sourceConfig || !targetConfig) {
      message.error('请先配置源数据库和目标数据库连接');
      return;
    }

    setLoading(true);
    try {
      const response = await compareApi.startComparison(sourceConfig, targetConfig);
      
      if (response.success) {
        setComparisonTaskId(response.data?.taskId || null);
        setCurrentStep(1);
        message.success('数据库比较任务已启动');
      } else {
        message.error(response.error || '启动比较任务失败');
      }
    } catch (error: any) {
      console.error('启动比较失败:', error);
      message.error('启动比较任务失败');
    } finally {
      setLoading(false);
    }
  };

  // 比较完成处理
  const handleComparisonComplete = (result: any) => {
    setComparisonResult(result.result);
    setCurrentStep(2);
    message.success('数据库比较已完成！');
  };

  // 比较错误处理
  const handleComparisonError = (error: string) => {
    message.error(`比较过程发生错误: ${error}`);
  };

  // 重新开始
  const restart = () => {
    setCurrentStep(0);
    setSourceConfig(null);
    setTargetConfig(null);
    setComparisonTaskId(null);
    setComparisonResult(null);
  };

  // 检查是否可以进行下一步
  const canProceedToComparison = () => {
    return sourceConfig && targetConfig;
  };

  return (
    <Layout style={{ minHeight: '100vh', background: '#f0f2f5' }}>
      <Header style={{ background: '#fff', padding: '0 24px', borderBottom: '1px solid #f0f0f0' }}>
        <Row align="middle" style={{ height: '100%' }}>
          <Col>
            <Space>
              <DatabaseOutlined style={{ fontSize: '24px', color: '#1890ff' }} />
              <Title level={3} style={{ margin: 0, color: '#1890ff' }}>
                SQL Server 数据库比较工具
              </Title>
            </Space>
          </Col>
        </Row>
      </Header>

      <Content style={{ padding: '24px' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          {/* 步骤指示器 */}
          <Card style={{ marginBottom: 24 }}>
            <Steps current={currentStep} items={steps} />
          </Card>

          {/* 步骤内容 */}
          {currentStep === 0 && (
            <Space direction="vertical" style={{ width: '100%' }} size="large">
              <Alert
                message="配置数据库连接"
                description="请分别配置源数据库和目标数据库的连接信息。系统将比较这两个数据库的结构差异。"
                type="info"
                showIcon
              />

              <Row gutter={[24, 24]}>
                <Col xs={24} lg={12}>
                  <DatabaseConfigForm
                    title="源数据库"
                    onConfigChange={setSourceConfig}
                    onTestSuccess={(config) => {
                      setSourceConfig(config);
                      message.success('源数据库连接配置成功');
                    }}
                  />
                </Col>
                <Col xs={24} lg={12}>
                  <DatabaseConfigForm
                    title="目标数据库"
                    onConfigChange={setTargetConfig}
                    onTestSuccess={(config) => {
                      setTargetConfig(config);
                      message.success('目标数据库连接配置成功');
                    }}
                  />
                </Col>
              </Row>

              <Card>
                <Space style={{ width: '100%', justifyContent: 'center' }}>
                  <Button
                    type="primary"
                    size="large"
                    onClick={startComparison}
                    disabled={!canProceedToComparison()}
                    loading={loading}
                  >
                    开始数据库比较
                  </Button>
                </Space>
                {!canProceedToComparison() && (
                  <div style={{ textAlign: 'center', marginTop: 12 }}>
                    <Paragraph type="secondary">
                      请先完成源数据库和目标数据库的连接测试
                    </Paragraph>
                  </div>
                )}
              </Card>
            </Space>
          )}

          {currentStep === 1 && comparisonTaskId && (
            <Space direction="vertical" style={{ width: '100%' }} size="large">
              <Alert
                message="正在执行数据库比较"
                description="系统正在分析两个数据库的结构差异，请耐心等待。您可以实时查看比较进度和执行日志。"
                type="info"
                showIcon
              />

              <ComparisonProgress
                taskId={comparisonTaskId}
                onComplete={handleComparisonComplete}
                onError={handleComparisonError}
              />

              <Card>
                <Space style={{ width: '100%', justifyContent: 'center' }}>
                  <Button onClick={restart}>
                    重新开始
                  </Button>
                </Space>
              </Card>
            </Space>
          )}

          {currentStep === 2 && comparisonResult && comparisonTaskId && (
            <Space direction="vertical" style={{ width: '100%' }} size="large">
              <Alert
                message="数据库比较完成"
                description="比较结果已生成，您可以查看详细的差异信息并生成报告文件。"
                type="success"
                showIcon
              />

              <ComparisonResults
                taskId={comparisonTaskId}
                result={comparisonResult}
              />

              <Card>
                <Space style={{ width: '100%', justifyContent: 'center' }}>
                  <Button onClick={restart}>
                    进行新的比较
                  </Button>
                </Space>
              </Card>
            </Space>
          )}
        </div>
      </Content>
    </Layout>
  );
};

export default HomePage;