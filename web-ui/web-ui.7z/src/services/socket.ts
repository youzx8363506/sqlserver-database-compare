import { io, Socket } from 'socket.io-client';
import { ProgressEvent, LogEvent, CompleteEvent, ErrorEvent } from '../types';

class SocketService {
  private socket: Socket | null = null;
  private isConnected: boolean = false;

  // 连接到WebSocket服务器
  connect(url: string = 'ws://localhost:3001'): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.socket = io(url, {
          transports: ['websocket'],
          autoConnect: true,
        });

        this.socket.on('connect', () => {
          console.log('WebSocket连接成功');
          this.isConnected = true;
          resolve();
        });

        this.socket.on('disconnect', () => {
          console.log('WebSocket连接断开');
          this.isConnected = false;
        });

        this.socket.on('connect_error', (error) => {
          console.error('WebSocket连接错误:', error);
          this.isConnected = false;
          reject(error);
        });

      } catch (error) {
        console.error('创建WebSocket连接失败:', error);
        reject(error);
      }
    });
  }

  // 断开连接
  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
      this.isConnected = false;
    }
  }

  // 加入任务房间
  joinTask(taskId: string): void {
    if (this.socket && this.isConnected) {
      this.socket.emit('join-task', taskId);
      console.log(`加入任务房间: ${taskId}`);
    }
  }

  // 离开任务房间
  leaveTask(taskId: string): void {
    if (this.socket && this.isConnected) {
      this.socket.emit('leave-task', taskId);
      console.log(`离开任务房间: ${taskId}`);
    }
  }

  // 监听比较进度
  onProgress(callback: (progress: ProgressEvent) => void): void {
    if (this.socket) {
      this.socket.on('comparison-progress', callback);
    }
  }

  // 监听比较完成
  onComplete(callback: (result: CompleteEvent) => void): void {
    if (this.socket) {
      this.socket.on('comparison-complete', callback);
    }
  }

  // 监听错误
  onError(callback: (error: ErrorEvent) => void): void {
    if (this.socket) {
      this.socket.on('comparison-error', callback);
    }
  }

  // 监听日志消息
  onLog(callback: (log: LogEvent) => void): void {
    if (this.socket) {
      this.socket.on('log-message', callback);
    }
  }

  // 移除所有监听器
  removeAllListeners(): void {
    if (this.socket) {
      this.socket.removeAllListeners('comparison-progress');
      this.socket.removeAllListeners('comparison-complete');
      this.socket.removeAllListeners('comparison-error');
      this.socket.removeAllListeners('log-message');
    }
  }

  // 检查连接状态
  isSocketConnected(): boolean {
    return this.isConnected && this.socket?.connected === true;
  }

  // 获取连接ID
  getSocketId(): string | undefined {
    return this.socket?.id;
  }
}

// 创建单例实例
export const socketService = new SocketService();

export default socketService;