import axios from 'axios';
import { DatabaseConfig, ApiResponse, ComparisonTask, ComparisonResult, Report } from '../types';

const API_BASE_URL = '/api';

// 创建axios实例
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 响应拦截器
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API请求错误:', error);
    return Promise.reject(error);
  }
);

// 数据库相关API
export const databaseApi = {
  // 测试数据库连接
  testConnection: async (config: DatabaseConfig): Promise<ApiResponse> => {
    const response = await api.post('/database/test-connection', config);
    return response.data;
  },

  // 获取数据库对象列表
  getObjects: async (
    config: DatabaseConfig,
    objectType: string = 'tables'
  ): Promise<ApiResponse> => {
    const params = {
      server: config.server,
      database: config.database,
      authType: config.authentication.type,
      username: config.authentication.username,
      password: config.authentication.password,
      objectType,
    };
    const response = await api.get('/database/objects', { params });
    return response.data;
  },

  // 获取数据库信息
  getInfo: async (config: DatabaseConfig): Promise<ApiResponse> => {
    const params = {
      server: config.server,
      database: config.database,
      authType: config.authentication.type,
      username: config.authentication.username,
      password: config.authentication.password,
    };
    const response = await api.get('/database/info', { params });
    return response.data;
  },
};

// 比较相关API
export const compareApi = {
  // 启动比较任务
  startComparison: async (
    sourceDatabase: DatabaseConfig,
    targetDatabase: DatabaseConfig,
    options?: any
  ): Promise<ApiResponse<{ taskId: string; websocketUrl: string }>> => {
    const response = await api.post('/compare/start', {
      sourceDatabase,
      targetDatabase,
      options,
    });
    return response.data;
  },

  // 获取任务状态
  getTaskStatus: async (taskId: string): Promise<ApiResponse<{ task: ComparisonTask }>> => {
    const response = await api.get(`/compare/status/${taskId}`);
    return response.data;
  },

  // 获取比较结果
  getTaskResult: async (taskId: string): Promise<ApiResponse<{ result: ComparisonResult }>> => {
    const response = await api.get(`/compare/result/${taskId}`);
    return response.data;
  },

  // 获取详细差异数据
  getDifferences: async (
    taskId: string,
    type: 'tables' | 'indexes' | 'views' | 'procedures' | 'functions',
    page: number = 1,
    limit: number = 50
  ): Promise<ApiResponse> => {
    const response = await api.get(`/compare/differences/${taskId}/${type}`, {
      params: { page, limit },
    });
    return response.data;
  },

  // 清理过期任务
  cleanupTasks: async (): Promise<ApiResponse> => {
    const response = await api.delete('/compare/cleanup');
    return response.data;
  },
};

// 报告相关API
export const reportsApi = {
  // 生成报告
  generateReport: async (
    taskId: string,
    format: 'html' | 'excel' | 'json',
    options?: any
  ): Promise<ApiResponse<{ report: Report }>> => {
    const response = await api.post(`/reports/generate/${taskId}`, {
      format,
      options,
    });
    return response.data;
  },

  // 获取报告列表
  getReports: async (): Promise<ApiResponse<{ reports: Report[]; count: number }>> => {
    const response = await api.get('/reports/list');
    return response.data;
  },

  // 获取报告信息
  getReportInfo: async (fileName: string): Promise<ApiResponse<{ report: Report }>> => {
    const response = await api.get(`/reports/info/${fileName}`);
    return response.data;
  },

  // 删除报告
  deleteReport: async (fileName: string): Promise<ApiResponse> => {
    const response = await api.delete(`/reports/${fileName}`);
    return response.data;
  },

  // 清理过期报告
  cleanupReports: async (days: number): Promise<ApiResponse> => {
    const response = await api.delete(`/reports/cleanup/${days}`);
    return response.data;
  },
};

// 健康检查
export const healthApi = {
  check: async (): Promise<ApiResponse> => {
    const response = await api.get('/health');
    return response.data;
  },
};

export default api;