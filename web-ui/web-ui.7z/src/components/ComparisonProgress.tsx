import React, { useState, useEffect } from 'react';
import {
  Card,
  Progress,
  Typography,
  Space,
  List,
  Tag,
  Button,
  Alert,
} from 'antd';
import {
  CheckCircleOutlined,
  CloseCircleOutlined,
  InfoCircleOutlined,
  ReloadOutlined,
} from '@ant-design/icons';
import { ProgressEvent, LogEvent, CompleteEvent, ErrorEvent } from '../types';
import socketService from '../services/socket';

const { Title, Text } = Typography;

interface ComparisonProgressProps {
  taskId: string;
  onComplete?: (result: any) => void;
  onError?: (error: string) => void;
}

interface LogEntry extends LogEvent {
  id: string;
}

const ComparisonProgress: React.FC<ComparisonProgressProps> = ({
  taskId,
  onComplete,
  onError,
}) => {
  const [progress, setProgress] = useState<number>(0);
  const [currentStep, setCurrentStep] = useState<string>('准备开始比较...');
  const [status, setStatus] = useState<'running' | 'completed' | 'failed'>('running');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isSocketConnected, setIsSocketConnected] = useState(false);

  // 添加日志条目
  const addLog = (log: LogEvent) => {
    const logEntry: LogEntry = {
      ...log,
      id: `${Date.now()}-${Math.random()}`,
    };
    setLogs(prev => [logEntry, ...prev.slice(0, 99)]); // 保持最新100条日志
  };

  // 连接WebSocket并设置监听器
  const setupWebSocket = async () => {
    try {
      if (!socketService.isSocketConnected()) {
        await socketService.connect();
      }

      setIsSocketConnected(true);

      // 加入任务房间
      socketService.joinTask(taskId);

      // 设置监听器
      socketService.onProgress((progressData: ProgressEvent) => {
        setProgress(progressData.percentage);
        setCurrentStep(progressData.message);
        addLog({
          level: 'info',
          message: `${progressData.step}: ${progressData.message}`,
          timestamp: new Date().toISOString(),
        });
      });

      socketService.onComplete((result: CompleteEvent) => {
        setProgress(100);
        setCurrentStep('比较完成');
        setStatus('completed');
        addLog({
          level: 'info',
          message: '数据库比较已完成！',
          timestamp: new Date().toISOString(),
        });
        onComplete?.(result);
      });

      socketService.onError((errorData: ErrorEvent) => {
        setStatus('failed');
        setError(errorData.error);
        addLog({
          level: 'error',
          message: `错误: ${errorData.error}`,
          timestamp: new Date().toISOString(),
        });
        onError?.(errorData.error);
      });

      socketService.onLog((logData: LogEvent) => {
        addLog(logData);
      });

    } catch (error: any) {
      console.error('WebSocket连接失败:', error);
      setIsSocketConnected(false);
      addLog({
        level: 'error',
        message: `WebSocket连接失败: ${error.message}`,
        timestamp: new Date().toISOString(),
      });
    }
  };

  // 重新连接WebSocket
  const reconnectWebSocket = () => {
    socketService.disconnect();
    setIsSocketConnected(false);
    setupWebSocket();
  };

  // 组件挂载时设置WebSocket
  useEffect(() => {
    setupWebSocket();

    return () => {
      // 组件卸载时清理
      socketService.leaveTask(taskId);
      socketService.removeAllListeners();
    };
  }, [taskId]);

  // 获取状态图标
  const getStatusIcon = () => {
    switch (status) {
      case 'running':
        return <InfoCircleOutlined spin style={{ color: '#1890ff' }} />;
      case 'completed':
        return <CheckCircleOutlined style={{ color: '#52c41a' }} />;
      case 'failed':
        return <CloseCircleOutlined style={{ color: '#ff4d4f' }} />;
      default:
        return <InfoCircleOutlined />;
    }
  };

  // 获取状态标签
  const getStatusTag = () => {
    switch (status) {
      case 'running':
        return <Tag icon={<InfoCircleOutlined spin />} color="processing">运行中</Tag>;
      case 'completed':
        return <Tag icon={<CheckCircleOutlined />} color="success">已完成</Tag>;
      case 'failed':
        return <Tag icon={<CloseCircleOutlined />} color="error">失败</Tag>;
      default:
        return <Tag>未知</Tag>;
    }
  };

  return (
    <Card
      title={
        <Space>
          {getStatusIcon()}
          <Title level={4} style={{ margin: 0 }}>
            比较进度
          </Title>
          {getStatusTag()}
        </Space>
      }
      extra={
        !isSocketConnected && (
          <Button
            icon={<ReloadOutlined />}
            onClick={reconnectWebSocket}
            size="small"
          >
            重新连接
          </Button>
        )
      }
    >
      <Space direction="vertical" style={{ width: '100%' }} size="large">
        {/* 进度条 */}
        <div>
          <div style={{ marginBottom: 8 }}>
            <Text strong>{currentStep}</Text>
          </div>
          <Progress
            percent={progress}
            status={status === 'failed' ? 'exception' : status === 'completed' ? 'success' : 'active'}
            strokeColor={{
              '0%': '#108ee9',
              '100%': '#87d068',
            }}
          />
        </div>

        {/* WebSocket连接状态 */}
        {!isSocketConnected && (
          <Alert
            message="WebSocket连接断开"
            description="实时进度更新已停止，请点击重新连接按钮恢复连接"
            type="warning"
            showIcon
            action={
              <Button size="small" onClick={reconnectWebSocket}>
                重新连接
              </Button>
            }
          />
        )}

        {/* 错误信息 */}
        {error && (
          <Alert
            message="比较过程发生错误"
            description={error}
            type="error"
            showIcon
          />
        )}

        {/* 日志列表 */}
        <div>
          <Title level={5}>执行日志</Title>
          <div style={{ maxHeight: 300, overflowY: 'auto' }}>
            <List
              size="small"
              dataSource={logs}
              renderItem={(log) => (
                <List.Item key={log.id}>
                  <Space style={{ width: '100%' }}>
                    {log.level === 'error' && <CloseCircleOutlined style={{ color: '#ff4d4f' }} />}
                    {log.level === 'warn' && <InfoCircleOutlined style={{ color: '#faad14' }} />}
                    {log.level === 'info' && <InfoCircleOutlined style={{ color: '#1890ff' }} />}
                    <Text style={{ flex: 1 }}>{log.message}</Text>
                    <Text type="secondary" style={{ fontSize: '12px' }}>
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </Text>
                  </Space>
                </List.Item>
              )}
              locale={{ emptyText: '暂无日志' }}
            />
          </div>
        </div>
      </Space>
    </Card>
  );
};

export default ComparisonProgress;