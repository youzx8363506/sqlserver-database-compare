import React, { useState } from 'react';
import {
  Form,
  Input,
  Select,
  Button,
  Card,
  Space,
  Typography,
  Alert,
  message,
} from 'antd';
import {
  DatabaseOutlined,
  UserOutlined,
  LockOutlined,
  CheckCircleOutlined,
} from '@ant-design/icons';
import { DatabaseConfig } from '../types';
import { databaseApi } from '../services/api';

const { Title, Text } = Typography;
const { Option } = Select;

interface DatabaseConfigFormProps {
  title: string;
  initialValues?: Partial<DatabaseConfig>;
  onConfigChange?: (config: DatabaseConfig) => void;
  onTestSuccess?: (config: DatabaseConfig) => void;
  disabled?: boolean;
}

const DatabaseConfigForm: React.FC<DatabaseConfigFormProps> = ({
  title,
  initialValues,
  onConfigChange,
  onTestSuccess,
  disabled = false,
}) => {
  const [form] = Form.useForm();
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    message: string;
  } | null>(null);
  const [authType, setAuthType] = useState<'windows' | 'sql'>(
    initialValues?.authentication?.type || 'windows'
  );

  // 处理认证类型变化
  const handleAuthTypeChange = (value: 'windows' | 'sql') => {
    setAuthType(value);
    // 清除测试结果
    setTestResult(null);
  };

  // 处理表单值变化
  const handleFormChange = () => {
    const values = form.getFieldsValue();
    if (values.server && values.database) {
      const config: DatabaseConfig = {
        server: values.server,
        database: values.database,
        authentication: {
          type: authType,
          username: authType === 'sql' ? values.username : undefined,
          password: authType === 'sql' ? values.password : undefined,
        },
      };
      onConfigChange?.(config);
    }
  };

  // 测试数据库连接
  const handleTestConnection = async () => {
    try {
      const values = await form.validateFields();
      setTesting(true);
      setTestResult(null);

      const config: DatabaseConfig = {
        server: values.server,
        database: values.database,
        authentication: {
          type: authType,
          username: authType === 'sql' ? values.username : undefined,
          password: authType === 'sql' ? values.password : undefined,
        },
      };

      const response = await databaseApi.testConnection(config);
      
      if (response.success) {
        setTestResult({
          success: true,
          message: response.message || '数据库连接成功！',
        });
        message.success('数据库连接测试成功！');
        onTestSuccess?.(config);
      } else {
        setTestResult({
          success: false,
          message: response.error || '数据库连接失败',
        });
        message.error('数据库连接测试失败！');
      }
    } catch (error: any) {
      console.error('测试连接失败:', error);
      setTestResult({
        success: false,
        message: error.response?.data?.error || error.message || '连接测试失败',
      });
      message.error('数据库连接测试失败！');
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card 
      title={
        <Space>
          <DatabaseOutlined />
          <Title level={4} style={{ margin: 0 }}>
            {title}
          </Title>
        </Space>
      }
      style={{ marginBottom: 16 }}
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={{
          server: initialValues?.server || '',
          database: initialValues?.database || '',
          authType: initialValues?.authentication?.type || 'windows',
          username: initialValues?.authentication?.username || '',
          password: initialValues?.authentication?.password || '',
        }}
        onValuesChange={handleFormChange}
        disabled={disabled}
      >
        <Form.Item
          name="server"
          label={
            <Space>
              <DatabaseOutlined />
              <Text>服务器地址</Text>
            </Space>
          }
          rules={[
            { required: true, message: '请输入服务器地址' },
            { min: 1, message: '服务器地址不能为空' },
          ]}
        >
          <Input
            placeholder="例如：localhost 或 192.168.1.100 或 SERVER\\INSTANCE"
            size="large"
          />
        </Form.Item>

        <Form.Item
          name="database"
          label={
            <Space>
              <DatabaseOutlined />
              <Text>数据库名称</Text>
            </Space>
          }
          rules={[
            { required: true, message: '请输入数据库名称' },
            { min: 1, message: '数据库名称不能为空' },
          ]}
        >
          <Input
            placeholder="例如：MyDatabase"
            size="large"
          />
        </Form.Item>

        <Form.Item
          name="authType"
          label="认证方式"
          rules={[{ required: true, message: '请选择认证方式' }]}
        >
          <Select
            value={authType}
            onChange={handleAuthTypeChange}
            size="large"
            placeholder="选择认证方式"
          >
            <Option value="windows">Windows 认证</Option>
            <Option value="sql">SQL Server 认证</Option>
          </Select>
        </Form.Item>

        {authType === 'sql' && (
          <>
            <Form.Item
              name="username"
              label={
                <Space>
                  <UserOutlined />
                  <Text>用户名</Text>
                </Space>
              }
              rules={[
                { required: true, message: '请输入用户名' },
                { min: 1, message: '用户名不能为空' },
              ]}
            >
              <Input
                placeholder="SQL Server 用户名"
                size="large"
              />
            </Form.Item>

            <Form.Item
              name="password"
              label={
                <Space>
                  <LockOutlined />
                  <Text>密码</Text>
                </Space>
              }
              rules={[
                { required: true, message: '请输入密码' },
                { min: 1, message: '密码不能为空' },
              ]}
            >
              <Input.Password
                placeholder="SQL Server 密码"
                size="large"
              />
            </Form.Item>
          </>
        )}

        <Form.Item>
          <Button
            type="primary"
            icon={<CheckCircleOutlined />}
            onClick={handleTestConnection}
            loading={testing}
            disabled={disabled}
            size="large"
            block
          >
            {testing ? '测试连接中...' : '测试数据库连接'}
          </Button>
        </Form.Item>

        {testResult && (
          <Alert
            message={testResult.success ? '连接成功' : '连接失败'}
            description={testResult.message}
            type={testResult.success ? 'success' : 'error'}
            showIcon
            style={{ marginTop: 16 }}
          />
        )}
      </Form>
    </Card>
  );
};

export default DatabaseConfigForm;