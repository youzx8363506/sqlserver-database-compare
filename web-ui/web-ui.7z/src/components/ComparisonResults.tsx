import React, { useState, useEffect } from 'react';
import {
  Card,
  Tabs,
  Table,
  Typography,
  Space,
  Button,
  Tag,
  Statistic,
  Row,
  Col,
  Alert,
  Modal,
  Select,
  message,
  Tooltip,
  Empty,
} from 'antd';
import {
  FileTextOutlined,
  DownloadOutlined,
  EyeOutlined,
  TableOutlined,
  DatabaseOutlined,
  CopyOutlined,
} from '@ant-design/icons';
import { ComparisonResult, Report } from '../types';
import { compareApi, reportsApi } from '../services/api';

const { Title, Text } = Typography;
const { TabPane } = Tabs;
const { Option } = Select;

interface ComparisonResultsProps {
  taskId: string;
  result: ComparisonResult;
}

const ComparisonResults: React.FC<ComparisonResultsProps> = ({
  taskId,
  result,
}) => {
  const [activeTab, setActiveTab] = useState('summary');
  const [detailData, setDetailData] = useState<any>({});
  const [loading, setLoading] = useState<any>({});
  const [reportModalVisible, setReportModalVisible] = useState(false);
  const [generatingReport, setGeneratingReport] = useState(false);
  const [reports, setReports] = useState<Report[]>([]);
  const [selectedFormat, setSelectedFormat] = useState<'html' | 'excel' | 'json'>('html');

  // 差异类型配置
  const differenceTypes = [
    { key: 'tables', title: '表结构', icon: <TableOutlined />, count: result.differences.tables.length },
    { key: 'indexes', title: '索引', icon: <TableOutlined />, count: result.differences.indexes.length },
    { key: 'views', title: '视图', icon: <EyeOutlined />, count: result.differences.views.length },
    { key: 'procedures', title: '存储过程', icon: <DatabaseOutlined />, count: result.differences.procedures.length },
    { key: 'functions', title: '函数', icon: <DatabaseOutlined />, count: result.differences.functions.length },
  ];

  // 获取详细差异数据
  const fetchDetailData = async (type: string) => {
    if (detailData[type]) return; // 已经加载过

    setLoading((prev: any) => ({ ...prev, [type]: true }));
    try {
      const response = await compareApi.getDifferences(taskId, type as any);
      if (response.success) {
        setDetailData((prev: any) => ({
          ...prev,
          [type]: response.data || []
        }));
      }
    } catch (error) {
      message.error(`获取${type}详细数据失败`);
    } finally {
      setLoading((prev: any) => ({ ...prev, [type]: false }));
    }
  };

  // 生成报告
  const generateReport = async () => {
    setGeneratingReport(true);
    try {
      const response = await reportsApi.generateReport(taskId, selectedFormat);
      if (response.success) {
        message.success('报告生成成功！');
        setReportModalVisible(false);
        fetchReports(); // 刷新报告列表
      } else {
        message.error(response.error || '报告生成失败');
      }
    } catch (error: any) {
      console.error('生成报告失败:', error);
      message.error('报告生成失败');
    } finally {
      setGeneratingReport(false);
    }
  };

  // 获取报告列表
  const fetchReports = async () => {
    try {
      const response = await reportsApi.getReports();
      if (response.success) {
        // 过滤出当前任务的报告
        const taskReports = response.data?.reports.filter((report: Report) => 
          report.taskId === taskId
        );
        setReports(taskReports || []);
      }
    } catch (error) {
      console.error('获取报告列表失败:', error);
    }
  };

  // 复制链接到剪贴板
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      message.success('链接已复制到剪贴板');
    }).catch(() => {
      message.error('复制失败');
    });
  };

  // 打开报告链接
  const openReportLink = (url: string) => {
    window.open(url, '_blank');
  };

  // 组件挂载时获取报告列表
  useEffect(() => {
    fetchReports();
  }, [taskId]);

  // 处理Tab切换
  const handleTabChange = (key: string) => {
    setActiveTab(key);
    if (key !== 'summary' && key !== 'reports') {
      fetchDetailData(key);
    }
  };

  // 获取差异类型的表格列配置
  const getTableColumns = (_type: string) => {
    const baseColumns = [
      {
        title: '名称',
        dataIndex: 'name',
        key: 'name',
        render: (text: string) => <Text strong>{text}</Text>,
      },
      {
        title: '操作类型',
        dataIndex: 'type',
        key: 'type',
        render: (type: string) => {
          const colors: any = {
            'added': 'green',
            'removed': 'red',
            'modified': 'orange',
          };
          return <Tag color={colors[type] || 'blue'}>{type}</Tag>;
        },
      },
      {
        title: '说明',
        dataIndex: 'description',
        key: 'description',
        ellipsis: true,
      },
    ];

    return baseColumns;
  };

  return (
    <Card
      title={
        <Space>
          <FileTextOutlined />
          <Title level={4} style={{ margin: 0 }}>
            比较结果
          </Title>
        </Space>
      }
      extra={
        <Space>
          <Button
            type="primary"
            icon={<DownloadOutlined />}
            onClick={() => setReportModalVisible(true)}
          >
            生成报告
          </Button>
        </Space>
      }
    >
      <Tabs activeKey={activeTab} onChange={handleTabChange}>
        {/* 摘要Tab */}
        <TabPane tab="摘要" key="summary">
          <Space direction="vertical" style={{ width: '100%' }} size="large">
            {/* 统计信息 */}
            <Row gutter={[16, 16]}>
              <Col span={12}>
                <Card size="small">
                  <Statistic
                    title="源数据库"
                    value={result.summary.sourceDatabase}
                    prefix={<DatabaseOutlined />}
                  />
                </Card>
              </Col>
              <Col span={12}>
                <Card size="small">
                  <Statistic
                    title="目标数据库"
                    value={result.summary.targetDatabase}
                    prefix={<DatabaseOutlined />}
                  />
                </Card>
              </Col>
            </Row>

            <Row gutter={[16, 16]}>
              <Col span={8}>
                <Card size="small">
                  <Statistic
                    title="总差异数"
                    value={result.summary.totalDifferences}
                    valueStyle={{ color: result.summary.totalDifferences > 0 ? '#cf1322' : '#3f8600' }}
                  />
                </Card>
              </Col>
              <Col span={8}>
                <Card size="small">
                  <Statistic
                    title="比较时间"
                    value={new Date(result.summary.comparedAt).toLocaleString()}
                  />
                </Card>
              </Col>
              <Col span={8}>
                <Card size="small">
                  <Statistic
                    title="任务ID"
                    value={taskId.substring(0, 8)}
                    suffix="..."
                  />
                </Card>
              </Col>
            </Row>

            {/* 差异分布 */}
            <Card title="差异分布" size="small">
              <Row gutter={[16, 16]}>
                {differenceTypes.map(type => (
                  <Col span={12} md={8} lg={6} key={type.key}>
                    <Card size="small" style={{ textAlign: 'center' }}>
                      <Space direction="vertical">
                        {type.icon}
                        <Text strong>{type.title}</Text>
                        <Tag color={type.count > 0 ? 'red' : 'green'}>
                          {type.count} 个差异
                        </Tag>
                      </Space>
                    </Card>
                  </Col>
                ))}
              </Row>
            </Card>

            {result.summary.totalDifferences === 0 && (
              <Alert
                message="数据库结构一致"
                description="源数据库和目标数据库的结构完全一致，没有发现任何差异。"
                type="success"
                showIcon
              />
            )}
          </Space>
        </TabPane>

        {/* 详细差异Tabs */}
        {differenceTypes.map(type => (
          <TabPane
            tab={
              <Space>
                {type.icon}
                {type.title}
                <Tag>{type.count}</Tag>
              </Space>
            }
            key={type.key}
          >
            {type.count === 0 ? (
              <Empty 
                description={`没有${type.title}差异`}
                image={Empty.PRESENTED_IMAGE_SIMPLE}
              />
            ) : (
              <Table
                dataSource={detailData[type.key] || []}
                columns={getTableColumns(type.key)}
                loading={loading[type.key]}
                pagination={{
                  pageSize: 10,
                  showSizeChanger: true,
                  showQuickJumper: true,
                  showTotal: (total) => `共 ${total} 条记录`,
                }}
                scroll={{ x: true }}
              />
            )}
          </TabPane>
        ))}

        {/* 报告Tab */}
        <TabPane tab="报告链接" key="reports">
          <Space direction="vertical" style={{ width: '100%' }} size="large">
            <Alert
              message="报告链接说明"
              description="生成的报告文件包含完整的比较结果，您可以下载或直接在浏览器中查看。支持HTML、Excel和JSON格式。"
              type="info"
              showIcon
            />

            {reports.length === 0 ? (
              <Empty 
                description="暂无报告文件"
                image={Empty.PRESENTED_IMAGE_SIMPLE}
              >
                <Button
                  type="primary"
                  icon={<DownloadOutlined />}
                  onClick={() => setReportModalVisible(true)}
                >
                  生成第一个报告
                </Button>
              </Empty>
            ) : (
              <Table
                dataSource={reports}
                columns={[
                  {
                    title: '文件名',
                    dataIndex: 'fileName',
                    key: 'fileName',
                    render: (text: string) => <Text code>{text}</Text>,
                  },
                  {
                    title: '格式',
                    dataIndex: 'format',
                    key: 'format',
                    render: (format: string) => (
                      <Tag color={format === 'html' ? 'blue' : format === 'excel' ? 'green' : 'orange'}>
                        {format.toUpperCase()}
                      </Tag>
                    ),
                  },
                  {
                    title: '大小',
                    dataIndex: 'size',
                    key: 'size',
                    render: (size: number) => `${(size / 1024).toFixed(1)} KB`,
                  },
                  {
                    title: '创建时间',
                    dataIndex: 'createdAt',
                    key: 'createdAt',
                    render: (time: string) => new Date(time).toLocaleString(),
                  },
                  {
                    title: '操作',
                    key: 'actions',
                    render: (_, record: Report) => (
                      <Space>
                        <Tooltip title="在新窗口打开">
                          <Button
                            type="primary"
                            size="small"
                            icon={<EyeOutlined />}
                            onClick={() => openReportLink(record.downloadUrl)}
                          >
                            查看
                          </Button>
                        </Tooltip>
                        <Tooltip title="复制链接地址">
                          <Button
                            size="small"
                            icon={<CopyOutlined />}
                            onClick={() => copyToClipboard(record.downloadUrl)}
                          >
                            复制链接
                          </Button>
                        </Tooltip>
                        <Tooltip title="下载文件">
                          <Button
                            size="small"
                            icon={<DownloadOutlined />}
                            href={record.downloadUrl}
                            download={record.fileName}
                          >
                            下载
                          </Button>
                        </Tooltip>
                      </Space>
                    ),
                  },
                ]}
                pagination={false}
                size="small"
              />
            )}
          </Space>
        </TabPane>
      </Tabs>

      {/* 生成报告弹窗 */}
      <Modal
        title="生成比较报告"
        open={reportModalVisible}
        onOk={generateReport}
        onCancel={() => setReportModalVisible(false)}
        confirmLoading={generatingReport}
        okText="生成报告"
        cancelText="取消"
      >
        <Space direction="vertical" style={{ width: '100%' }}>
          <Text>选择报告格式：</Text>
          <Select
            value={selectedFormat}
            onChange={setSelectedFormat}
            style={{ width: '100%' }}
            size="large"
          >
            <Option value="html">
              <Space>
                <FileTextOutlined />
                HTML 格式 - 适合在线查看
              </Space>
            </Option>
            <Option value="excel">
              <Space>
                <TableOutlined />
                Excel 格式 - 适合数据分析
              </Space>
            </Option>
            <Option value="json">
              <Space>
                <DatabaseOutlined />
                JSON 格式 - 适合程序处理
              </Space>
            </Option>
          </Select>
          <Alert
            message="报告内容说明"
            description="报告将包含完整的数据库比较结果，包括所有差异的详细信息、统计数据和比较摘要。"
            type="info"
            showIcon
          />
        </Space>
      </Modal>
    </Card>
  );
};

export default ComparisonResults;